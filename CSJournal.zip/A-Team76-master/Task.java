package application;

/**
 * Object of a task of the day.
 * 
 * @author Aaksh Ranjan
 *
 */
public class Task {

  private String task;
  private boolean done;

  /**
   * Constructor to create the Task Object.
   */
  public Task(String task) {
    this.task = task;
    this.done = false;
  }

  /**
   * Task getter method.
   * 
   * @return
   */
  public String getTask() {
    return task;
  }

  /**
   * Task setter method.
   * 
   * @param task
   */
  public void setTask(String task) {
    this.task = task;
  }

  /**
   * Done getter method.
   * 
   * @return
   */
  public boolean getDone() {
    return done;
  }

  /**
   * Done setter method.
   * 
   * @param done
   */
  public void setDone(boolean done) {
    this.done = done;
  }

}
