package application;

import java.util.ArrayList;
import java.util.Calendar;

public class TO_DOS {

  private ArrayList<Task> tasks;
  private int numberOfTasks;
  private Calendar entryDate;
  private int day;
  private int month;
  private int year;

  /**
   * Constructor for the TO_DOS object
   */
  public TO_DOS() {
    tasks = new ArrayList<Task>();
    numberOfTasks = 0;
    entryDate = Calendar.getInstance();
    day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
    month = Calendar.getInstance().get(Calendar.MONTH);
    year = Calendar.getInstance().get(Calendar.YEAR);

  }

  /**
   * This method will be used to create an ArralyList of Tasks, using a string of tasks each
   * separated by a new line.
   *
   * @param tasks - tasks to be added
   */
  public void setTasks(String tasks) {
    // Getting an array of new tasks by splitting.
    String[] newTasks = tasks.split("\\R", -1);

    // Adding the new tasks to the ArrayList.
    for (int i = 0; i < newTasks.length; i++) {
      // Creating a new task to add to the tasks ArrayList.
      Task task = new Task(newTasks[i]);

      // Adding the new Task to the ArrayList.
      this.tasks.add(task);

      // Increment the numberOfTasks by 1.
      numberOfTasks++;
    }
  }

  /**
   * Returns the tasks ArrayList as a String, each task separated by a new line.
   *
   * @return
   */
  public String getTasks() {
    // Creating an new empty StringBuilder.
    StringBuilder tasksString = new StringBuilder();

    // Creating a String of Tasks, each task separated by a new line.
    for (int i = 0; i < tasks.size(); i++) {
      tasksString.append(tasks.get(i).getTask()).append("\r\n");
    }

    return tasksString.toString();
  }



  public int getNumTasks() {
    return this.numberOfTasks;
  }

  /**
   * This method returns the day of the month of object on the day of creation.
   *
   * @return
   */
  public int getDay() {
    return day;
  }

  /**
   * This method returns the month of object on the day of creation.
   *
   * @return
   */
  public int getMonth() {
    return month;
  }

  /**
   * This method returns the year of object on the day of creation.
   *
   * @return
   */
  public int getYear() {
    return year;
  }

  public Calendar getDate() {
    return entryDate;
  }

  /**
   * Setter method to update the date of the journal entry.
   *
   * @param day   - day number to update entry date to
   * @param month - month number to update entry date to
   * @param year  - year number to update entry date to
   */
  public void setDate(int day, int month, int year) {
    this.day = day;
    this.month = month;
    this.year = year;
  }

  @Override public String toString() {
    StringBuilder returnString = new StringBuilder();
    for (Task t : tasks) {
      returnString.append(t + ", ");
    }
    return returnString.toString();
  }
}
