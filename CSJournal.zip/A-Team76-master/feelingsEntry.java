package application;

import java.util.Calendar;

/**
 * This object will store the feelings of the user for that day.
 *
 * @author Stephen Paoli II
 *
 */
public class feelingsEntry {

  // Variable to keep track of the user's feeling strength on a scale from
  // 1-10.
  private int feelingScore;

  // Variable to keep track of a String which contains an explaination of what
  // the user is feeling.
  private String feelingExplain;

  // A calendar object to keep track of the entry date of this entry.
  private Calendar entryDate;

  private int day;
  private int month;
  private int year;

  /**
   * Constructor for the feeling object.
   *
   * @param feelingScore - 1-10 score of the strength of the user's feeling.
   * @param feelingExplain - explanation of what the user is feeling.
   */
  public feelingsEntry(int feelingScore, String feelingExplain) {
    this.feelingScore = feelingScore;
    this.feelingExplain = feelingExplain;
    entryDate = Calendar.getInstance();
    day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
    month = Calendar.getInstance().get(Calendar.MONTH);
    year = Calendar.getInstance().get(Calendar.YEAR);

  }

  /**
   * This method returns the day of the month that this object was created.
   * @return
   */
  public int getDay() {
    return day;
  }

  /**
   * This method returns the month that this object was created.
   */
  public int getMonth() {
    return month;
  }

  /**
   * This method returns the year that this object was created.
   */
  public int getYear() {
    return year;
  }

  /**
   * Getter method for feeling score.
   */
  public int getFeelingScore() {
    return feelingScore;
  }

  /**
   * Getter method for feeling explanation.
   */
  public String getFeelingExplain() {
    return feelingExplain;
  }

  /**
   * Setter method for feeling score.
   */
  public void setFeelingScore(int score) {
    feelingScore = score;
  }

  /**
   * Setter method for feeling explanation.
   */
  public void setFeelingExplain(String explain) {
    feelingExplain = explain;
  }

  public Calendar getDate() {
    return entryDate;
  }

  /**
   * Setter method to update the date of the journal entry.
   * @param day - day number to update entry date to
   * @param month - month number to update entry date to
   * @param year - year number to update entry date to
   */
  public void setDate(int day, int month, int year) {
    this.day = day;
    this.month = month;
    this.year = year;
  }
}
