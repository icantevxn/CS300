package application;

import java.util.Calendar;

/**
 * This object will store the habit of the user for that day.
 *
 * @author Aaksh Ranjan
 *
 */
public class Habits {

  private int water;
  private int sleep;
  private int exercise;
  private int day;
  private int month;
  private int year;
  private Calendar entryDate;

  /**
   * Constructor for the habit object.
   *
   * @param sleep - numbers of time sleep task has been completed
   * @param water - numbers of time water task has been completed
   * @param exercise - numbers of time exercise task has been completed
   */
  public Habits(int sleep, int water, int exercise) {
    // Setting the private class variables.
    this.sleep = sleep;
    this.water = water;
    this.exercise = exercise;
    entryDate = Calendar.getInstance();
    day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
    month = Calendar.getInstance().get(Calendar.MONTH);
    year = Calendar.getInstance().get(Calendar.YEAR);
  }

  /**
   * This method returns the day of the month of object on the day of creation.
   *
   * @return
   */
  public int getDay() {
    return day;
  }

  /**
   * This method returns the month of object on the day of creation.
   *
   * @return
   */
  public int getMonth() {
    return month;
  }

  /**
   * This method returns the year of object on the day of creation.
   *
   * @return
   */
  public int getYear() {
    return year;
  }

  /**
   * Getter method for water.
   *
   * @return
   */
  public int getWater() {
    return water;
  }

  /**
   * setter method for water.
   */

  public void setWater(int water) {
    this.water = water;
  }

  /**
   * Getter method for sleep.
   *
   * @return
   */
  public int getSleep() {
    return sleep;
  }

  /**
   * setter method for sleep.
   */
  public void setSleep(int sleep) {
    this.sleep = sleep;
  }

  /**
   * Getter method for sleep.
   *
   * @return
   */
  public int getExercise() {
    return exercise;
  }

  /**
   * setter method for sleep.
   */
  public void setExercise(int exercise) {
    this.exercise = exercise;
  }

  /**
   * getter method for date
   * @returns date
   */
  public Calendar getDate() {
    return entryDate;
  }

  /**
   * Setter method to update the date of the journal entry.
   * @param day - day number to update entry date to
   * @param month - month number to update entry date to
   * @param year - year number to update entry date to
   */
  public void setDate(int day, int month, int year) {
    this.day = day;
    this.month = month;
    this.year = year;
  }
}
