package application;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONArray;

public class Account {

  String username;
  String password;
  String file;

  /**
   * Constructor for the account object.
   * 
   * @param username
   * @param password
   * @throws IOException
   */
  public Account(String username, String password) throws IOException {
    // initializing the username and password variables.
    this.username = username;
    this.password = password;
    this.file = username + ".json";

    // seeing if user's file containing journals already exists, else create the file.
    File userJournal = new File(file);
    if (!(userJournal.exists())) {
      userJournal.createNewFile();
      JSONArray Journal = new JSONArray();
      Journal.add(new JSONArray());
      Journal.add(new JSONArray());
      Journal.add(new JSONArray());
      // write the json object into the file.
      FileWriter writeFile = new FileWriter(file);
      writeFile.write(Journal.toString());
      writeFile.flush();
      writeFile.close();
    }
  }

  /**
   * Getter method for username.
   * 
   * @return
   */
  public String getUsername() {
    return username;
  }

  /**
   * Getter method for password.
   * 
   * @return
   */
  public String getPassword() {
    return password;
  }

  /**
   * Getter method for file.
   * 
   * @return
   */
  public String getFile() {
    return file;
  }

  @Override
  public String toString() {
    return getUsername() + getPassword();

  }

}
