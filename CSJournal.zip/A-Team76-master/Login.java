package application;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Class to make a Login object. This object will be used to login and create accounts.
 * 
 * @author Aaksh Ranjan
 *
 */
public class Login {

  ArrayList<Account> accounts;
  File accountsFile;
  JSONArray accountArray;

  /**
   * This is the constructor for the Login Object, it loads up a json file if it exists, else it
   * makes one then loads its up.
   * 
   * @throws IOException
   * @throws ParseException
   */
  public Login() throws IOException, ParseException {
    accounts = new ArrayList<Account>();

    String file = "Account.json";

    // seeing if account's file already exists, else create the file.
    File accountsFile = new File(file);
    if (!(accountsFile.exists())) {
      accountsFile.createNewFile();
      JSONArray Account = new JSONArray();
      // write the json object into the file.
      FileWriter writeFile = new FileWriter(file);
      writeFile.write(Account.toString());
      writeFile.flush();
      writeFile.close();
    }

    // Read the json file and load all the accounts into the ArrayList.
    JSONParser parser = new JSONParser();

    // parsing the json file.
    Object obj = parser.parse(new FileReader(file));

    // getting the accounts array.
    accountArray = (JSONArray) obj;

    for (int i = 0; i < accountArray.size(); i++) {
      JSONArray account = (JSONArray) accountArray.get(i);

      // Getting the username and password for that account.
      String Username = (String) account.get(0);
      String Password = (String) account.get(1);

      // Creating an new account object with the username and password.
      Account accountTemp = new Account(Username, Password);

      // Add this account to the array list.
      accounts.add(accountTemp);
    }
  }

  /**
   * this method is used to create an new account.
   * 
   * @param Username
   * @param Password
   * @throws IOException
   */
  public Boolean signUp(String Username, String Password) throws IOException {

    // check if username already exists.
    for (int i = 0; i < accounts.size(); i++) {
      Account accountTemp = accounts.get(i);

      if (accountTemp.getUsername().equals(Username)) {
        return false;
      }
    }

    // creating an JSONArray with username and password.
    JSONArray account = new JSONArray();

    // Adding the username and password to the array.
    account.add(Username);
    account.add(Password);

    // getting the accounts array.
    accountArray.add(account);

    // write the new json object into the file.
    FileWriter writeFile = new FileWriter("Account.json");
    writeFile.write(accountArray.toString());
    writeFile.flush();
    writeFile.close();

    // Finally Add this account to the ArrayList.
    Account accountTemp = new Account(Username, Password);

    // Add the account to the arraylist.
    accounts.add(accountTemp);

    return true;

  }

  public String signIn(String Username, String Password) {
    // Check if any accounts have the same username and password.
    for (int i = 0; i < accounts.size(); i++) {
      Account accountTemp = accounts.get(i);

      if (accountTemp.getUsername().equals(Username)) {
        if (accountTemp.getPassword().equals(Password)) {
          return accountTemp.getFile();
        }
      }
    }
    return "Not Found";
  }

}
