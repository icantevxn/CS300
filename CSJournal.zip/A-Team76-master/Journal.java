package application;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;

/**
 * @author Andrew Mitty and Evangeline Lim
 */

public class Journal {
  String name;
  ToDoJournal toDoJournal;
  HabitJournal habitJournal;
  FeelingsJournal feelingsJournal;
  JSONArray journal;
  String filePath;

  public Journal(String filePath) throws IOException, ParseException {
    this.filePath = filePath;
    // created a parser object and parsed the file
    JSONParser parser = new JSONParser();
    Object obj = parser.parse(new FileReader(filePath));
    journal = (JSONArray) obj;

    JSONArray habits = (JSONArray) journal.get(0);

    // 0:day, 1:month, 2:year, 3:Sleep, 4: Water, 5: Exercise
    // transfer habits into LinkedList
    LinkedList<Habits> habitsList = new LinkedList();
    for (int i = 0; i < habits.size(); i++) {
      JSONArray tempHabits = (JSONArray) habits.get(i);
      int day = ((Long) tempHabits.get(0)).intValue();
      int month = ((Long) tempHabits.get(1)).intValue();
      int year = ((Long) tempHabits.get(2)).intValue();
      int sleep = ((Long) tempHabits.get(3)).intValue();
      int water = ((Long) tempHabits.get(4)).intValue();
      int exercise = ((Long) tempHabits.get(5)).intValue();

      Habits temp = new Habits(sleep, water, exercise);
      temp.setDate(day, month, year);
      habitsList.add(temp);
    }
    // Transfer todo to LinkedList
    JSONArray todo = (JSONArray) journal.get(1);
    LinkedList<TO_DOS> todoList = new LinkedList<>();
    for (int i = 0; i < todo.size(); i++) {
      JSONArray tempTODO = (JSONArray) todo.get(i);
      int day = ((Long) tempTODO.get(0)).intValue();
      int month = ((Long) tempTODO.get(1)).intValue();
      int year = ((Long) tempTODO.get(2)).intValue();
      String tasks = (String) tempTODO.get(3);
      TO_DOS temp = new TO_DOS();
      temp.setTasks(tasks);
      temp.setDate(day, month, year);
      todoList.add(temp);
    }
    // Transfer feelings to LinkedList
    JSONArray feelings = (JSONArray) journal.get(2);
    LinkedList<feelingsEntry> feelingsList = new LinkedList<>();
    for (int i = 0; i < feelings.size(); i++) {
      // JSONObject json;
      JSONArray tempFeelings = (JSONArray) feelings.get(i);
      int day = ((Long) tempFeelings.get(0)).intValue();
      int month = ((Long) tempFeelings.get(1)).intValue();
      int year = ((Long) tempFeelings.get(2)).intValue();
      int feelingNum = ((Long) tempFeelings.get(3)).intValue();
      String feelingString = (String) tempFeelings.get(4);
      feelingsEntry temp = new feelingsEntry(feelingNum, feelingString);
      temp.setDate(day, month, year);
      feelingsList.add(temp);
    }

    toDoJournal = new ToDoJournal(filePath);
    feelingsJournal = new FeelingsJournal(filePath);
    habitJournal = new HabitJournal(filePath);

    toDoJournal.setEntries(todoList);
    feelingsJournal.setEntries(feelingsList);
    habitJournal.setEntries(habitsList);
  }// end constructor

  public void exportTODO(String todos) throws IOException {
    FileWriter writer = new FileWriter(filePath);

    JSONArray todo = (JSONArray) journal.get(1);
    JSONArray todoTemp = new JSONArray();

    todoTemp.add(Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
    todoTemp.add(Calendar.getInstance().get(Calendar.MONTH));
    todoTemp.add(Calendar.getInstance().get(Calendar.YEAR));
    todoTemp.add(todos);
    todo.add(todoTemp);

    writer.write(journal.toString());
    writer.flush();
    writer.close();

    toDoJournal.addEntry(todos);

  }

  public void exportFeeling(int feelingNum, String feelingString) throws IOException {
    FileWriter writer = new FileWriter(filePath);

    JSONArray feeling = (JSONArray) journal.get(2);
    JSONArray feelingTemp = new JSONArray();

    feelingTemp.add(Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
    feelingTemp.add(Calendar.getInstance().get(Calendar.MONTH));
    feelingTemp.add(Calendar.getInstance().get(Calendar.YEAR));
    feelingTemp.add(feelingNum);
    feelingTemp.add(feelingString);
    feeling.add(feelingTemp);

    writer.write(journal.toString());
    writer.flush();
    writer.close();

    feelingsJournal.addEntry(feelingNum, feelingString);

  }

  public void exportHabit(int sleep, int water, int exercise) throws IOException {
    FileWriter writer = new FileWriter(filePath);

    JSONArray habit = (JSONArray) journal.get(0);
    JSONArray habitTemp = new JSONArray();

    habitTemp.add(Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
    habitTemp.add(Calendar.getInstance().get(Calendar.MONTH));
    habitTemp.add(Calendar.getInstance().get(Calendar.YEAR));
    habitTemp.add(sleep);
    habitTemp.add(water);
    habitTemp.add(exercise);
    habit.add(habitTemp);

    writer.write(journal.toString());
    writer.flush();
    writer.close();

    habitJournal.addEntry(sleep, water, exercise);

  }

  /**
   * Takes in a date and returns a string describing three habits.
   *
   * @param day
   * @param month
   * @param year
   * @return a string of habits. if no entry found, returns null.
   * @throws FileNotFoundException
   */
  public String previewHabit(int year, int month, int day) throws FileNotFoundException {

    String entry;
    int exercise = 0;
    int sleep = 0;
    int water = 0;
    //for (Habits ent : habitJournal.entries) {
      //if (ent.getYear() == year && ent.getMonth() == month && ent.getDay() == day) {
    Habits ent = null;
    try {
      ent = habitJournal.getEntry(year, month, day);
      exercise = exercise + ent.getExercise();
      sleep = sleep + ent.getSleep();
      water = water + ent.getWater();
    } catch (EntryNotFoundException e) {
    }

      //}
   // }
    entry = year + "/" + month + "/" + day + "'s Habits Entry.\n" + "Total Hours of Exercise: "
        + exercise + ".\n" + "Total Hours of Sleep: " + sleep + ".\n"
        + "Total Cups of Water Consumed: " + water + ".\n";
    return entry;
  }

  /**
   * Takes in a date and returns the to-do list for that date
   *
   * @param day
   * @param month
   * @param year
   * @return a string of to-dos. if no entry found, returns null.
   * @throws FileNotFoundException
   */
  public String previewToDo(int year, int month, int day) throws FileNotFoundException {

    String entry = "";
    int todo = 0;
    String task = "";
    try {
      TO_DOS ent = toDoJournal.getEntry(year, month, day);
      todo += ent.getNumTasks();
      task = task.concat(ent.getTasks());
    } catch (EntryNotFoundException e) {

    }
    //    for (int i = 0; i < toDoJournal.getEntries().size(); i++) {
//      if (toDoJournal.getEntries().get(i).getDay() == day
//          && toDoJournal.getEntries().get(i).getMonth() == month - 1
//          && toDoJournal.getEntries().get(i).getYear() == year) {
//        todo = todo + toDoJournal.getEntries().get(i).getNumTasks();
//        task = task.concat(toDoJournal.getEntries().get(i).getTasks());
//      }
//    }
    entry = year + "/" + month + "/" + day + "'s To-Do List.\n" + "Total Number of Tasks: " + todo
        + ".\n" + "All Tasks: " + task + ".\n";
    return entry;
  }

  /**
   * Takes in the date and returns a preview of feeling entry for that date
   *
   * @param day
   * @param month
   * @param year
   * @return a string describing feeling. if no entry found, returns null.
   * @throws FileNotFoundException
   */
  public String previewFeelings(int year, int month, int day) throws FileNotFoundException {
    String entry;
    int feelingScore = 0;
    int count = 0;
    String feelingExplain = "";
    try {
      feelingsEntry ent = feelingsJournal.getEntry(year,month,day);
      count++;
      feelingScore += ent.getFeelingScore();
      feelingExplain = ent.getFeelingExplain().concat(", ").concat(feelingExplain);
    } catch (EntryNotFoundException e) {
    }
    //    for (int i = 0; i < feelingsJournal.getEntries().size(); i++) {
//      if (feelingsJournal.getEntries().get(i).getDay() == day
//          && feelingsJournal.getEntries().get(i).getMonth() == month - 1
//          && feelingsJournal.getEntries().get(i).getYear() == year) {
//        count++;
//        feelingScore =
//            (feelingScore + feelingsJournal.getEntries().get(i).getFeelingScore()) / count;
//        feelingExplain = feelingsJournal.getEntries().get(i).getFeelingExplain().concat(", ")
//            .concat(feelingExplain);
//      }
//    }
    entry = year + "/" + month + "/" + day + "'s Feelings.\n" + "You feel " + feelingExplain
        + " today.\n" + "This is how emotional you feel: " + feelingScore + ".\n";
    return entry;

  }

  /**
   * Calculates the average habits over the month based on the amount of days a journal entry was
   * entered e.g: if only 12 days out of 31 days were filled, the average habits is taken with 12
   * days and not 31
   *
   * @param wantMonth - user inputs wanted month
   * @param wantYear  - user inputs wanted year
   * @return a double array of the mean of 3 different habits: sleep, exercise and drinking water.
   * @throws EntryNotFoundException
   */
  private double[] analysisMonthHabit(int wantMonth, int wantYear) throws EntryNotFoundException {
    // for month
    ArrayList<Integer> habitDays = new ArrayList<Integer>();
    int exercise = 0;
    int sleep = 0;
    int water = 0;
    double meanExercise = 0;
    double meanSleep = 0;
    double meanWater = 0;
    // toDoJournal;
    // habitJournal;
    // feelingsJournal;

    for (int i = 0; i < habitJournal.getEntries().size(); i++) {
      if (wantMonth == habitJournal.getEntries().get(i).getMonth() && wantYear == habitJournal
          .getEntries().get(i).getYear()) {
        habitDays.add(habitJournal.getEntries().get(i).getDay());
      }
    }
    for (int j = 0; j < habitDays.size(); j++) {
      exercise =
          exercise + habitJournal.getEntry(wantYear, wantMonth, habitDays.get(j)).getExercise();
      sleep = sleep + habitJournal.getEntry(wantYear, wantMonth, habitDays.get(j)).getSleep();
      water = water + habitJournal.getEntry(wantYear, wantMonth, habitDays.get(j)).getWater();
    }

    // total calculations (calculating average based on only days entered)

    // habits
    meanExercise = exercise / habitDays.size();
    meanSleep = sleep / habitDays.size();
    meanWater = water / habitDays.size();

    double[] results = new double[] {meanExercise, meanSleep, meanWater};
    return results;
  }

  /**
   * Calculates the total and average tasks done in a month based ont he number of entries entered
   *
   * @param wantMonth
   * @param wantYear
   * @return a double array of total tasks done and mean task for the month
   * @throws EntryNotFoundException
   */
  private double[] analysisMonthToDo(int wantMonth, int wantYear) throws EntryNotFoundException {
    // todo
    ArrayList<Integer> todoDays = new ArrayList<Integer>();
    int todo = 0;
    double meanTask;
    double total;

    for (int i = 0; i < toDoJournal.getEntries().size(); i++) {
      if (wantMonth == toDoJournal.getEntries().get(i).getMonth() && wantYear == toDoJournal
          .getEntries().get(i).getYear()) {
        todoDays.add(toDoJournal.getEntries().get(i).getDay());
      }
    }

    for (int j = 0; j < todoDays.size(); j++) {
      todo = todo + toDoJournal.getEntry(wantYear, wantMonth, todoDays.get(j)).getNumTasks();
    }

    // todo
    meanTask = todo / todoDays.size();
    total = (double) todo;

    double[] results = new double[] {total, meanTask};
    return results;

  }

  /**
   * Calculates how emotional be it negative or positive emotions, the user is for the month
   *
   * @param wantMonth
   * @param wantYear
   * @return an array list of array list consisting of the all the days that has a entry, the
   * emotional scale for that day and the average feeling score
   * @throws EntryNotFoundException
   */
  private ArrayList<ArrayList<Integer>> analysisMonthFeeling(int wantMonth, int wantYear)
      throws EntryNotFoundException {

    // feelings
    ArrayList<Integer> feelingDays = new ArrayList<Integer>();
    ArrayList<Integer> emotional = new ArrayList<Integer>();
    int emotion = 0;

    for (int i = 0; i < feelingsJournal.getEntries().size(); i++) {
      if (wantMonth == feelingsJournal.getEntries().get(i).getMonth() && wantYear == feelingsJournal
          .getEntries().get(i).getYear()) {
        feelingDays.add(feelingsJournal.getEntries().get(i).getDay());
      }
    }

    for (int j = 0; j < feelingDays.size(); j++) {
      emotional
          .add(feelingsJournal.getEntry(wantYear, wantMonth, feelingDays.get(j)).getFeelingScore());
      emotion = emotion + feelingsJournal.getEntry(wantYear, wantMonth, feelingDays.get(j))
          .getFeelingScore();
    }

    // average
    ArrayList<Integer> meanEmotion = new ArrayList<Integer>();
    meanEmotion.add(emotion / feelingDays.size());

    ArrayList<ArrayList<Integer>> resultsFeeling = new ArrayList<ArrayList<Integer>>();

    resultsFeeling.add(feelingDays);
    resultsFeeling.add(emotional);
    resultsFeeling.add(meanEmotion);

    return resultsFeeling;

  }

  /**
   * Helper method to check if the year is a leap year
   *
   * @param year
   * @return true if leap
   */
  private boolean leapYear(int year) {

    if (year % 4 == 0) {
      if (year % 100 == 0) {
        // year is divisible by 400, hence the year is a leap year
        if (year % 400 == 0)
          return true;
        else
          return false;
      } else
        return true;
    } else
      return false;

  }

  /**
   * Calculate the average habits in a year
   *
   * @param wantYear
   * @throws EntryNotFoundException
   * @returns a array of the average exercise
   */
  private double[] analysisYearHabit(int wantYear) throws EntryNotFoundException {

    int exercise = 0;
    int sleep = 0;
    int water = 0;

    for (int i = 0; i < habitJournal.getEntries().size(); i++) {
      if (wantYear == habitJournal.getEntries().get(i).getYear()) {
        exercise = exercise + habitJournal.getEntries().get(i).getExercise();
      }
      sleep = sleep + habitJournal.getEntries().get(i).getSleep();
      water = water + habitJournal.getEntries().get(i).getWater();
    }

    double meanExercise;
    double meanSleep;
    double meanWater;

    if (leapYear(wantYear)) {
      meanExercise = exercise / 366;
      meanSleep = sleep / 366;
      meanWater = water / 366;
    } else {
      meanExercise = exercise / 365;
      meanSleep = sleep / 365;
      meanWater = water / 365;
    }

    double[] results = new double[] {meanExercise, meanSleep, meanWater};

    return results;
  }

  /**
   * Calculates the total tasks for the year and average tasks per day.
   *
   * @param wantYear
   * @return
   * @throws EntryNotFoundException
   */
  private double[] analysisYearToDo(int wantYear) throws EntryNotFoundException {
    int todo = 0;

    for (int i = 0; i < toDoJournal.getEntries().size(); i++) {
      if (wantYear == toDoJournal.getEntries().get(i).getYear()) {
        todo = todo + toDoJournal.getEntries().get(i).getNumTasks();
      }
    }

    double total = todo;
    double meanTasks;

    if (leapYear(wantYear)) {
      meanTasks = todo / 366;

    } else {
      meanTasks = todo / 365;
    }

    double[] results = {total, meanTasks};
    return results;
  }

  /**
   * Calculates the average strength of emotions, be it good or bad, monthly and gives an average
   * score for the year.
   *
   * @param wantYear
   * @return a double array of the averages for each month and the entire year.
   * @throws EntryNotFoundException
   */
  private double[][] analysisYearFeelings(int wantYear) throws EntryNotFoundException {

    int jan = 0;
    int feb = 0;
    int mar = 0;
    int apr = 0;
    int may = 0;
    int jun = 0;
    int jul = 0;
    int aug = 0;
    int sept = 0;
    int oct = 0;
    int nov = 0;
    int dec = 0;

    for (int i = 0; i < feelingsJournal.getEntries().size(); i++) {
      if (wantYear == feelingsJournal.getEntries().get(i).getYear()) {

        if (feelingsJournal.getEntries().get(i).getMonth() == 1) {
          jan = jan + feelingsJournal.getEntries().get(i).getFeelingScore();
        }
        if (feelingsJournal.getEntries().get(i).getMonth() == 2) {
          feb = feb + feelingsJournal.getEntries().get(i).getFeelingScore();
        }
        if (feelingsJournal.getEntries().get(i).getMonth() == 3) {
          mar = mar + feelingsJournal.getEntries().get(i).getFeelingScore();
        }
        if (feelingsJournal.getEntries().get(i).getMonth() == 4) {
          apr = apr + feelingsJournal.getEntries().get(i).getFeelingScore();
        }
        if (feelingsJournal.getEntries().get(i).getMonth() == 5) {
          may = may + feelingsJournal.getEntries().get(i).getFeelingScore();
        }
        if (feelingsJournal.getEntries().get(i).getMonth() == 6) {
          jun = jun + feelingsJournal.getEntries().get(i).getFeelingScore();
        }
        if (feelingsJournal.getEntries().get(i).getMonth() == 7) {
          jul = jul + feelingsJournal.getEntries().get(i).getFeelingScore();
        }
        if (feelingsJournal.getEntries().get(i).getMonth() == 8) {
          aug = aug + feelingsJournal.getEntries().get(i).getFeelingScore();
        }
        if (feelingsJournal.getEntries().get(i).getMonth() == 9) {
          sept = sept + feelingsJournal.getEntries().get(i).getFeelingScore();
        }
        if (feelingsJournal.getEntries().get(i).getMonth() == 10) {
          oct = oct + feelingsJournal.getEntries().get(i).getFeelingScore();
        }
        if (feelingsJournal.getEntries().get(i).getMonth() == 11) {
          nov = nov + feelingsJournal.getEntries().get(i).getFeelingScore();
        }
        if (feelingsJournal.getEntries().get(i).getMonth() == 12) {
          dec = dec + feelingsJournal.getEntries().get(i).getFeelingScore();
        }

      }
    }

    double meanYear;
    if (leapYear(wantYear)) {
      meanYear = (jan + feb + mar + apr + may + jun + jul + aug + sept + oct + nov + dec) / 366;
    } else {
      meanYear = (jan + feb + mar + apr + may + jun + jul + aug + sept + oct + nov + dec) / 365;
    }
    double meanJan = jan / 31;
    double meanFeb;
    if (leapYear(wantYear)) {
      meanFeb = feb / 29;
    } else {
      meanFeb = feb / 28;
    }
    double meanMar = mar / 31;
    double meanApr = apr / 30;
    double meanMay = may / 31;
    double meanJun = jun / 30;
    double meanJul = jul / 31;
    double meanAug = aug / 31;
    double meanSept = sept / 30;
    double meanOct = oct / 31;
    double meanNov = nov / 30;
    double meanDec = dec / 31;

    double[][] result =
        {{meanJan, meanFeb, meanMar, meanApr, meanMay, meanJun, meanJul, meanAug, meanSept, meanOct,
            meanNov, meanDec}, {meanYear}};
    return result;
  }

  /**
   * Gets the name of the journal
   *
   * @return the name of the journal
   */
  public String getName() {
    return name;
  }

  /**
   * Sets the name of the journal
   *
   * @param name - the name the journal should be set to
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Gets the todoJournal Object from the journal
   *
   * @return the todoJournal stored in the journal object
   */
  public ToDoJournal getToDoJournal() {
    return toDoJournal;
  }

  /**
   * Sets the toDoJournal in the journal class to a different toDoJournal
   *
   * @param toDoJournal - the journal that should be set
   */
  public void setToDoJournal(ToDoJournal toDoJournal) {
    this.toDoJournal = toDoJournal;
  }

  /**
   * Gets the Habit Journal Object from the journal
   *
   * @return the Habit Journal stored in the journal object
   */
  public HabitJournal getHabitJournal() {
    return habitJournal;
  }

  /**
   * Sets the habit journal in the journal class to a different habit Journal
   *
   * @param habitJournal - the journal that should be set
   */
  public void setHabitJournal(HabitJournal habitJournal) {
    this.habitJournal = habitJournal;
  }

  /**
   * Gets the feeling Journal Object from the journal
   *
   * @return the feeling Journal stored in the journal object
   */
  public FeelingsJournal getFeelingsJournal() {
    return feelingsJournal;
  }

  /**
   * Sets the feelings journal in the journal class to a different feelings Journal
   *
   * @param feelingsJournal - the journal that should be set
   */
  public void setFeelingsJournal(FeelingsJournal feelingsJournal) {
    this.feelingsJournal = feelingsJournal;
  }


}
