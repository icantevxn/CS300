package application;

import java.util.LinkedList;

/**
 * A journal class that stores feelings entries
 *
 * @author Andrew Mitty
 */

public class FeelingsJournal {
  LinkedList<feelingsEntry> entries; //stores entries
  String name; //name of the journal

  /**
   * Instantiates the entries Linked List and sets the name
   *
   * @param name - the name of the journal
   */
  public FeelingsJournal(String name) {
    entries = new LinkedList<>();
    this.name = name;
  }

  /**
   * Adds an entry to the journal
   *
   * @param feelingScore   - Score of the feeling being entered 1-10
   * @param feelingExplain - The users feelings in a string
   */
  public void addEntry(int feelingScore, String feelingExplain) {
    feelingsEntry newEntry = new feelingsEntry(feelingScore, feelingExplain);
    entries.add(newEntry);
  }

  /**
   * Finds the specified entry and returns it
   *
   * @param year  - year of the entry
   * @param month - month of the entry
   * @param day   - day of the entry
   * @return the specified entry
   * @throws EntryNotFoundException - if the entry wasn't found
   */
  public feelingsEntry getEntry(int year, int month, int day) throws EntryNotFoundException {
    for (feelingsEntry entry : entries) {
      if (entry.getYear() == year && entry.getMonth() == month -1 && entry.getDay() == day) {
        return entry;
      }
    }
    throw new EntryNotFoundException();
  }

  /**
   * Gets the name of the journal
   *
   * @return - the name of the journal
   */
  public String getName() {
    return name;
  }

  /**
   * Sets all entries in the journal
   *
   * @param entries the entries to be set in a LinkedList
   */
  public void setEntries(LinkedList<feelingsEntry> entries) {
    this.entries = entries;
  }

  /**
   * Returns all of the entries in the journal in a linkedList
   *
   * @return a LinkedList of the entries
   */
  public LinkedList<feelingsEntry> getEntries() {
    return entries;
  }

}
