package application;

import java.util.LinkedList;

/**
 * A journal class that stores ToDo entries
 *
 * @author Andrew Mitty
 */
public class ToDoJournal {

  LinkedList<TO_DOS> entries;
  String name;

  /**
   * Instantiates the entries Linked List and sets the name
   *
   * @param name - the name of the journal
   */
  public ToDoJournal(String name) {
    entries = new LinkedList<>();
    this.name = name;
  }

  /**
   * Adds an entry to the journal
   *
   * @param tasks - the tasks to be added
   */
  public void addEntry(String tasks) {
    TO_DOS newEntry = new TO_DOS();
    newEntry.setTasks(tasks);
    entries.add(newEntry);
  }

  /**
   * Finds the specified entry and returns it
   *
   * @param year  - year of the entry
   * @param month - month of the entry
   * @param day   - day of the entry
   * @return the specified entry
   * @throws EntryNotFoundException - if the entry wasn't found
   */
  public TO_DOS getEntry(int year, int month, int day) throws EntryNotFoundException {
    for (TO_DOS entry : entries) {
      if (entry.getYear() == year && entry.getMonth() == month - 1 && entry.getDay() == day) {
        return entry;
      }
    }
    throw new EntryNotFoundException();
  }

  /**
   * Gets the name of the journal
   *
   * @return - the name of the journal
   */
  public String getName() {
    return name;
  }

  /**
   * Sets all entries in the journal
   *
   * @param importedEntries the entries to be set in a LinkedList
   */
  public void setEntries(LinkedList<TO_DOS> importedEntries) {
    for (TO_DOS entry: importedEntries) {
      entries.add(entry);
    }
  }

  /**
   * Returns all of the entries in the journal in a linkedList
   *
   * @return a LinkedList of the entries
   */
  public LinkedList<TO_DOS> getEntries() {
    return entries;
  }
}
