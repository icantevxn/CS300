package Application;
/**
 * Checked exception thrown when a non existent key is specified for get or remove.
 * DO NOT EDIT THIS CLASS
 */
@SuppressWarnings("serial")
public class EntryNotFoundException extends Exception {

    /**
     * default no-arg constructor
     */
    public EntryNotFoundException() { }

    /**
     * This constructor is provided to allow user to include a message
     * @param msg Additional message for this exception
     */
    public EntryNotFoundException(String msg) {
        super(msg);
    }

}

