package application;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import org.json.simple.parser.ParseException;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.chart.*;
import javafx.scene.Group;

public class Main extends Application {

	private List<String> args;
	private Journal journal;
	private String user;
	
	// Constants
	private static final int WINDOW_WIDTH = 600;
	private static final int WINDOW_HEIGHT = 450;
	private static final String APP_TITLE = "You've Got a Friend in Me!";
	private static final String[] JOURNAL_ENTRY_TYPES = new String[] { "To-Do", "Feelings", "Habit" };
	
	/**
	 * This the the start method of the application.
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {

		// Save Arguments
		args = this.getParameters().getRaw();
		
		// Top Bar (for all pages other than login)
		HBox topBar = new HBox();
		Button topBarHome = new Button("Home");
		Button topBarAccount = new Button("Account");
		Button topBarAbout = new Button("About Us");
		Button topBarLogout = new Button("Logout");
		HBox.setHgrow(topBarHome, Priority.ALWAYS);
		HBox.setHgrow(topBarAccount, Priority.ALWAYS);
		HBox.setHgrow(topBarAbout, Priority.ALWAYS);
		HBox.setHgrow(topBarLogout, Priority.ALWAYS);
		topBarHome.setMaxWidth(Double.MAX_VALUE);
		topBarAccount.setMaxWidth(Double.MAX_VALUE);
		topBarAbout.setMaxWidth(Double.MAX_VALUE);
		topBarLogout.setMaxWidth(Double.MAX_VALUE);
		topBar.getChildren().addAll(topBarHome, topBarAccount, topBarAbout, topBarLogout);
		
		// Bottom Bar (for all pages other than login)
		Label bottomLabel = new Label("A-Team 76, CS 400, Spring 2020");
		bottomLabel.setFont(Font.font("Arial", 10));
		BorderPane.setAlignment(bottomLabel, Pos.TOP_CENTER);
		
		//       PAGES
		//     ~~~~~~~~~
		
		//     LOGIN PAGE
		
		// Create Login object
		Login loginObject = new Login();
		
		// Main layout is Border Pane
		BorderPane login = new BorderPane();
		BackgroundFill backgroundFill = new BackgroundFill(Color.web("#FAF0E6"), CornerRadii.EMPTY, Insets.EMPTY);
		Background background = new Background(backgroundFill);
		login.setBackground(background);
		
		//   Title for the page
		Label loginLabel = new Label("You've Got a Friend in Me!");
		loginLabel.setFont(Font.font("Century Gothic", FontWeight.BOLD, 40));
		login.setCenter(loginLabel); // Setting page label to the center
		BorderPane.setAlignment(loginLabel, Pos.CENTER);
		
		//   Login Input
		VBox loginVBox = new VBox();
		loginVBox.setPadding(new Insets(0, 150, 50, 150));
		loginVBox.setSpacing(10);
		
		// Creating a user name HBox
		HBox usernameHBox = new HBox();
		usernameHBox.setPadding(new Insets(0, 0, 0, 20));
		usernameHBox.setSpacing(7);

		// Adding to the HBox
		Label usernameLabel = new Label("Username: ");
		TextField username = new TextField();
		usernameHBox.getChildren().addAll(usernameLabel, username);

		// Creating a password HBox
		HBox passwordHBox = new HBox();
		passwordHBox.setPadding(new Insets(0, 0, 0, 20));
		passwordHBox.setSpacing(10);

		// Adding to the HBox
		Label passwordLabel = new Label("Password: ");
		TextField password = new TextField();
		passwordHBox.getChildren().addAll(passwordLabel, password);
		
		// Output
		Label loginOutput = new Label("");
				
		//   Login and Sign Up Buttons
		HBox signInUpButtonsHBox = new HBox();
		signInUpButtonsHBox.setSpacing(10);
		
		Button loginButton = new Button("Sign In");
		loginButton.setOnMousePressed(e -> loginButton.setStyle("-fx-font-size:10pt"));
		loginButton.setOnMouseReleased(e -> loginButton.setStyle("-fx-font-size:9pt"));		
		
		Button signUpButton = new Button("Sign Up");
		signUpButton.setOnMousePressed(e -> loginButton.setStyle("-fx-font-size:10pt"));
		signUpButton.setOnMouseReleased(e -> loginButton.setStyle("-fx-font-size:9pt"));
		
		// Adding to the HBox and set alignment
		signInUpButtonsHBox.getChildren().addAll(loginButton, signUpButton);
		signInUpButtonsHBox.setAlignment(Pos.CENTER);
		loginVBox.setAlignment(Pos.CENTER);
		
		// Adding to the login VBox and place in BorderPane
		loginVBox.getChildren().addAll(usernameHBox, passwordHBox, signInUpButtonsHBox, loginOutput);
		login.setBottom(loginVBox);
		

		//     MAIN MENU PAGE
		
		BorderPane menu = new BorderPane();
		menu.setBackground(background);
		
		//   Menu Options
		
		// Creating a menu VBox
		VBox menuVBox = new VBox();
		menuVBox.setPadding(new Insets(30, 40, 30, 40));
		
		// Label for the page
		VBox menuLabelVBox = new VBox();
		Label menuLabel1 = new Label("Hi there,");
		Label menuLabel2 = new Label("What would you like to do today?");
		menuLabel1.setFont(Font.font("Arial", FontWeight.BOLD, 35));
		menuLabel2.setFont(Font.font("Arial", FontWeight.BOLD, 20));
		menuLabelVBox.getChildren().addAll(menuLabel1, menuLabel2);
		menuLabelVBox.setPadding(new Insets(0, 10, 10, 10));
		menuLabelVBox.setSpacing(5);
		
		// Creating a new entry button
		Button createEntryButton = new Button("Create a New Entry");
		VBox.setVgrow(createEntryButton, Priority.ALWAYS);
		createEntryButton.setMaxHeight(Double.MAX_VALUE);
		createEntryButton.setMaxWidth(Double.MAX_VALUE);
		createEntryButton.setStyle("-fx-background-color: #FFE4E1; -fx-border-color: #000000; "
				+ "-fx-border-width: 1px; -fx-font-size: 1.5em;");
		
		// Viewing previous entries button
		Button viewEntryButton = new Button("See Previous Entries");
		VBox.setVgrow(viewEntryButton, Priority.ALWAYS);
		viewEntryButton.setMaxHeight(Double.MAX_VALUE);
		viewEntryButton.setMaxWidth(Double.MAX_VALUE);
		viewEntryButton.setStyle("-fx-background-color: #FFE4E1; -fx-border-color: #000000; "
				+ "-fx-border-width: 1px; -fx-font-size: 1.5em;");
		
		// Viewing analysis button
		Button viewAnalysisButton = new Button("View Analyzed Details About You");
		VBox.setVgrow(viewAnalysisButton, Priority.ALWAYS);
		viewAnalysisButton.setMaxHeight(Double.MAX_VALUE);
		viewAnalysisButton.setMaxWidth(Double.MAX_VALUE);
		viewAnalysisButton.setStyle("-fx-background-color: #FFE4E1; -fx-border-color: #000000; "
				+ "-fx-border-width: 1px; -fx-font-size: 1.5em;");
		
		// Adding to the menu VBox and placing it in BorderPane
		menuVBox.getChildren().addAll(menuLabelVBox, createEntryButton, viewEntryButton, viewAnalysisButton);
		menu.setCenter(menuVBox);
		
	
		//     CREATE ENTRY PAGE
		
		BorderPane create = new BorderPane();
		create.setBackground(background);
		
		// Creating a VBox
		VBox createVBox = new VBox();
		createVBox.setPadding(new Insets(20, 10, 20, 10));
		createVBox.setSpacing(7);
		
		// Reminder
		Label createReminder = new Label("Only one entry is allowed per day. Do not click multiple times.");
		
		// Create habit entry
		Label createTitle = new Label("Let's create a journal entry!");
		createTitle.setFont(Font.font("Arial", FontWeight.BOLD, 25));
		TextField createWater = new TextField("");
		createWater.setPromptText("Cups of water drank today (int)");
		TextField createExercise = new TextField("");
		createExercise.setPromptText("Hours of exercise done today (int)");
		TextField createSleep = new TextField("");
		createSleep.setPromptText("Hours of sleep last night (int)");
		Button createHabitEntry = new Button("Create Habit Entry");
		createHabitEntry.setOnAction(e -> {
			try {
				journal.exportHabit(Integer.parseInt(createWater.getText()),
						Integer.parseInt(createExercise.getText()),
						Integer.parseInt(createSleep.getText()));
				Alert createAlert = new Alert(AlertType.INFORMATION, "Habit entry was successfully created.");
				createAlert.showAndWait().filter(response -> response == ButtonType.OK);
			} catch (NumberFormatException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
		}});
		
		// Create To-Do Entry
		TextArea createToDo = new TextArea();
		createToDo.setPromptText("Things to-do today, separated by a new line (String)");
		Button createToDoEntry = new Button("Create To-Do Entry");
		createToDoEntry.setOnAction(e -> {
			try {
				journal.exportTODO(createToDo.getText());
				Alert createAlert = new Alert(AlertType.INFORMATION, "To-Do entry was successfully created.");
				createAlert.showAndWait().filter(response -> response == ButtonType.OK);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
		
		// Create Feeling Entry
		TextField createFeelingScore = new TextField();
		createFeelingScore.setPromptText("Strength of emotions today (1-10)");
		TextArea createFeelingDescription = new TextArea();
		createFeelingDescription.setPromptText("Describe what you were feeling today in one word (String)");
		Button createFeelingsEntry = new Button("Create Feelings Entry");
		createFeelingsEntry.setOnAction(e -> {
			try {
				journal.exportFeeling(Integer.parseInt(createFeelingScore.getText()), 
						createFeelingDescription.getText());
				Alert createAlert = new Alert(AlertType.INFORMATION, "Feelings entry was successfully created.");
				createAlert.showAndWait().filter(response -> response == ButtonType.OK);
			} catch (NumberFormatException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
		
		createVBox.getChildren().addAll(createTitle, createReminder, createWater, createExercise, createSleep,
				createHabitEntry, createToDo, createToDoEntry, createFeelingScore, createFeelingDescription,
				createFeelingsEntry);
		
		create.setCenter(createVBox);

		//	   SEE PREVIOUS ENTRIES PAGE
		
		BorderPane previous = new BorderPane();
		previous.setBackground(background);
		
		// Creating a VBox
		VBox prevVBox = new VBox();
		prevVBox.setPadding(new Insets(0, 30, 0, 30));
		prevVBox.setSpacing(20);
		prevVBox.setAlignment(Pos.CENTER);
		
		Label prevPrompt = new Label("Which entry do you want to see?");
		prevPrompt.setFont(Font.font("Arial", FontWeight.BOLD, 25));
		TextField prevDate = new TextField();
		prevDate.setPromptText("Day");
		TextField prevDate2 = new TextField();
		prevDate2.setPromptText("Month");
		TextField prevDate3 = new TextField();
		prevDate3.setPromptText("Year");
		
		Button prevButton = new Button("Feelings");
		Button prevButton2 = new Button("To-Do");
		Button prevButton3 = new Button("Habits");
		
		Label prevOutput = new Label("");
		prevButton.setOnAction(e -> {
			try {
				prevOutput.setText(journal.previewFeelings(Integer.parseInt(prevDate3.getText()),
						Integer.parseInt(prevDate2.getText()), Integer.parseInt(prevDate.getText())));
			} catch (NumberFormatException e3) {
				e3.printStackTrace();
			} catch (FileNotFoundException e3) {
				e3.printStackTrace();
			}
		});
		prevButton2.setOnAction(e -> {
			try {
				prevOutput.setText(journal.previewToDo(Integer.parseInt(prevDate3.getText()),
						Integer.parseInt(prevDate2.getText()), Integer.parseInt(prevDate.getText())));
			} catch (NumberFormatException e3) {
				e3.printStackTrace();
			} catch (FileNotFoundException e3) {
				e3.printStackTrace();
			}
		});
		prevButton3.setOnAction(e -> {
			try {
				prevOutput.setText(journal.previewHabit(Integer.parseInt(prevDate3.getText()),
						Integer.parseInt(prevDate2.getText()), Integer.parseInt(prevDate.getText())));
			} catch (NumberFormatException e3) {
				e3.printStackTrace();
			} catch (FileNotFoundException e3) {
				e3.printStackTrace();
			}
		});
		
		prevVBox.getChildren().addAll(prevPrompt, prevDate, prevDate2, prevDate3, prevButton, prevButton2, prevButton3, prevOutput);
		previous.setCenter(prevVBox);
		

		//     ABOUT US PAGE
		
		BorderPane about = new BorderPane();
		about.setBackground(background);
		
		// Creating a VBox
		VBox aboutVBox = new VBox();
		aboutVBox.setPadding(new Insets(20, 20, 20, 20));
		aboutVBox.setSpacing(20);
		
		// Title
		Label aboutTitle = new Label("About Us");
		aboutTitle.setFont(Font.font("Arial", FontWeight.BOLD, 30));
		
		// Text
		Label aboutText = new Label("We are A-Team 76 bringing to you an interactive digital journal to help keep track of your thoughts,\n" + 
				"feelings, habits, and things to do. This �You�ve Got A Friend In Me� program will act as a\n" + 
				"friendly prompt to help the user write down and reflect their thoughts by asking\n" + 
				"questions in a friend-like manner with a user-friendly interface. This program is\n" + 
				"supposed to act as a therapist of sorts and document habits, feelings and reminders.");
		aboutText.setFont(Font.font("Helvetica", 10));
		
		// Adding to the VBox
		aboutVBox.getChildren().addAll(aboutTitle, aboutText);
		about.setCenter(aboutVBox);
		
		
		//     ANALYSIS PAGE
		
		BorderPane analysis = new BorderPane();
		analysis.setBackground(background);
		
		// Creating a VBox
		VBox analysisVBox = new VBox();
		analysisVBox.setPadding(new Insets(20, 20, 20, 20));
		analysisVBox.setSpacing(20);
		analysisVBox.setAlignment(Pos.CENTER);
		
		Label analysisTitle = new Label("Do you want to analyze by \nmonth or year?");
		analysisTitle.setFont(Font.font("Arial", FontWeight.BOLD, 30));
		HBox analysisButtonHBox = new HBox();
		analysisButtonHBox.setSpacing(30);
		analysisButtonHBox.setAlignment(Pos.CENTER);
		Button analysisMonth = new Button("Month");
		Button analysisYear = new Button("Year");
		analysisButtonHBox.getChildren().addAll(analysisMonth, analysisYear);
		
		// Adding to the VBox
		analysisVBox.getChildren().addAll(analysisTitle, analysisButtonHBox);
		analysis.setCenter(analysisVBox);
		
		
		//     ANALYSIS MONTH PAGE
		
		BorderPane analysisM = new BorderPane();
		analysisM.setBackground(background);
		
		// Creating VBox
		VBox analysisMVBox = new VBox();
		analysisMVBox.setSpacing(10);
		analysisMVBox.setAlignment(Pos.CENTER);
		
		// Enter year prompt
		HBox analysisMYearHBox = new HBox();
		Label analysisMTitle = new Label("Enter year:");
		TextField analysisMYear = new TextField();
		analysisMYear.setPromptText("Enter year here [yyyy] (int)");
		analysisMYearHBox.getChildren().addAll(analysisMTitle, analysisMYear);
		analysisMYearHBox.setAlignment(Pos.CENTER);
		
		// Enter month prompt
		HBox analysisMMonthHBox = new HBox();
		Label analysisMTitle2 = new Label("Enter month:");
		TextField analysisMMonth = new TextField();
		analysisMMonth.setPromptText("Enter month here (int)");
		analysisMMonthHBox.getChildren().addAll(analysisMTitle2, analysisMMonth);
		analysisMMonthHBox.setAlignment(Pos.CENTER);
		
		// Buttons
		Button analysisMButton = new Button("Feelings");
		Button analysisMButton2 = new Button("To-Do");
		Button analysisMButton3 = new Button("Habits");
		
		analysisMVBox.getChildren().addAll(analysisMYearHBox, analysisMMonthHBox, analysisMButton, analysisMButton2, analysisMButton3);
		analysisM.setCenter(analysisMVBox);
		
		//	   ANALYSIS YEAR PAGE
		
		BorderPane analysisY = new BorderPane();
		analysisY.setBackground(background);
		
		// Creating VBox
		VBox analysisYVBox = new VBox();
		
		Label analysisYTitle = new Label("Enter year:");
		TextField analysisYYear = new TextField();
		analysisYYear.setPromptText("Enter year here [yyyy] (int)");
		
		
		// List of Scenes
		Scene loginScene = new Scene(login, WINDOW_WIDTH, WINDOW_HEIGHT);
		Scene menuScene = new Scene(menu, WINDOW_WIDTH, WINDOW_HEIGHT);
		Scene createScene = new Scene(create, WINDOW_WIDTH, WINDOW_HEIGHT);
		Scene previousScene = new Scene(previous, WINDOW_WIDTH, WINDOW_HEIGHT);
		Scene aboutScene = new Scene(about, WINDOW_WIDTH, WINDOW_HEIGHT);
		Scene analysisScene = new Scene(analysis, WINDOW_WIDTH, WINDOW_HEIGHT);
		Scene analysisMScene = new Scene(analysisM, WINDOW_WIDTH, WINDOW_HEIGHT);
		Scene analysisYScene = new Scene(analysisY, WINDOW_WIDTH, WINDOW_HEIGHT);
		
		
		//     ACTIONS
		
		// Top Bar Actions
		topBarHome.setOnAction(e -> {primaryStage.setScene(menuScene);
		menu.setTop(topBar);
		menu.setBottom(bottomLabel);
		});
		topBarAccount.setOnAction(e -> {primaryStage.setScene(analysisScene);
		analysis.setTop(topBar);
		analysis.setBottom(bottomLabel);
		});
		topBarAbout.setOnAction(e -> {primaryStage.setScene(aboutScene);
		about.setTop(topBar);
		about.setBottom(bottomLabel);
		});
		topBarLogout.setOnAction(e -> Platform.exit());
		
		//   Login Actions
		
		// Sign In
		loginButton.setOnAction(e -> {
			String loginFile = loginObject.signIn(username.getText(), password.getText());
		if (loginFile.equals("Not Found")) {
			loginOutput.setText("Username and password does not match.");
		} else {
			try {
				journal = new Journal(loginFile);
			} catch (IOException e1) {
				e1.printStackTrace();
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
			primaryStage.setScene(menuScene);
			menu.setTop(topBar);
			menu.setBottom(bottomLabel);
		}
		});
		
		// Sign Up
		signUpButton.setOnAction(e -> {try {
			if (!loginObject.signUp(username.getText(), password.getText())) {
				loginOutput.setText("Username already exists.");
			} else {
				String loginFile = loginObject.signIn(username.getText(), password.getText());
				journal = new Journal(loginFile);
				primaryStage.setScene(menuScene);
				menu.setTop(topBar);
				menu.setBottom(bottomLabel);
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (ParseException e2) {
		};
		});
		
		// Menu Actions
		createEntryButton.setOnAction(e -> {primaryStage.setScene(createScene);
		create.setTop(topBar);
		create.setBottom(bottomLabel);
		});
		viewEntryButton.setOnAction(e -> {primaryStage.setScene(previousScene);
		previous.setTop(topBar);
		previous.setBottom(bottomLabel);
		});
		viewAnalysisButton.setOnAction(e -> {primaryStage.setScene(analysisScene);
		analysis.setTop(topBar);
		analysis.setBottom(bottomLabel);
		});
		
		// Analysis Actions
		analysisMonth.setOnAction(e -> {primaryStage.setScene(analysisMScene);
		analysisM.setTop(topBar);
		analysisM.setBottom(bottomLabel);
		});
		analysisYear.setOnAction(e -> {primaryStage.setScene(analysisYScene);
		analysisY.setTop(topBar);
		analysisY.setBottom(bottomLabel);
		});
		
		// Monthly Analysis Actions
		analysisMButton3.setOnAction(e -> {
			try {
				double[] results = journal.analysisMonthHabit(
						Integer.parseInt(analysisMMonth.getText()), 
						Integer.parseInt(analysisMYear.getText()));
				double meanExercise = results[0];
				double meanSleep = results[1];
				double meanWater = results[2];
				
				ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
			                new PieChart.Data("Mean Exercise", meanExercise),
			                new PieChart.Data("Mean Sleep", meanSleep),
			                new PieChart.Data("Mean Water", meanWater));
			        final PieChart chart = new PieChart(pieChartData);
			        chart.setTitle("Habits Analysis");

			    GridPane form = new GridPane();
			    form.getChildren().add(chart);
			    Scene chartScene = new Scene(form, 600,400);
			    final Stage dialog = new Stage();
			    dialog.initModality(Modality.APPLICATION_MODAL);
			    dialog.initOwner(primaryStage);
			    dialog.setScene(chartScene);
			    dialog.show();
				
			} catch (NumberFormatException e1) {
				e1.printStackTrace();
			} catch (EntryNotFoundException e1) {
				e1.printStackTrace();
			}
			});
		
		// Add the stuff and set the primary stage
		primaryStage.setTitle(APP_TITLE);
		primaryStage.setScene(loginScene);
		primaryStage.show();
	}

	/**
	 * This launches the start method.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);
	}
}
